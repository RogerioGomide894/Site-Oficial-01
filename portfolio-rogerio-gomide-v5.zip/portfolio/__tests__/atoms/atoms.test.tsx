/**
 * @jest-environment jsdom
 */
import React from "react";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import "@testing-library/jest-dom";

// ── Eyebrow ──────────────────────────────────────────────────────────────────
jest.mock("@/lib/utils", () => ({
  cn: (...c: string[]) => c.filter(Boolean).join(" "),
}));

import { Eyebrow } from "@/components/atoms/Eyebrow";
import { Heading } from "@/components/atoms/Heading";
import { Button } from "@/components/atoms/Button";
import { ThemeToggle } from "@/components/atoms/ThemeToggle";

describe("Eyebrow", () => {
  it("renders children text", () => {
    render(<Eyebrow>MINHA SEÇÃO</Eyebrow>);
    expect(screen.getByText("MINHA SEÇÃO")).toBeInTheDocument();
  });

  it("renders the decorative dot with aria-hidden", () => {
    const { container } = render(<Eyebrow>Test</Eyebrow>);
    const dot = container.querySelector("[aria-hidden='true']");
    expect(dot).toBeInTheDocument();
  });

  it("applies dark variant class", () => {
    const { container } = render(<Eyebrow variant="dark">Dark</Eyebrow>);
    expect(container.firstChild).toHaveClass("text-[#667087]");
  });
});

// ── Heading ──────────────────────────────────────────────────────────────────
describe("Heading", () => {
  it("renders as h1 when specified", () => {
    render(<Heading as="h1">Título</Heading>);
    expect(screen.getByRole("heading", { level: 1 })).toBeInTheDocument();
  });

  it("renders as h2 by default", () => {
    render(<Heading>Subtítulo</Heading>);
    expect(screen.getByRole("heading", { level: 2 })).toBeInTheDocument();
  });

  it("renders children content", () => {
    render(<Heading>Olá Mundo</Heading>);
    expect(screen.getByText("Olá Mundo")).toBeInTheDocument();
  });

  it("applies xl size class", () => {
    const { container } = render(<Heading size="xl">XL</Heading>);
    expect(container.firstChild).toHaveClass("text-[clamp(42px,5vw,70px)]");
  });
});

// ── Button ───────────────────────────────────────────────────────────────────
describe("Button", () => {
  it("renders as a <button> when no href", () => {
    render(<Button>Clique aqui</Button>);
    expect(screen.getByRole("button", { name: /clique aqui/i })).toBeInTheDocument();
  });

  it("calls onClick handler", async () => {
    const user = userEvent.setup();
    const onClick = jest.fn();
    render(<Button onClick={onClick}>Clicar</Button>);
    await user.click(screen.getByRole("button"));
    expect(onClick).toHaveBeenCalledTimes(1);
  });

  it("renders as a link when href is provided", () => {
    render(<Button href="#contato">Ver</Button>);
    expect(screen.getByRole("link", { name: /ver/i })).toBeInTheDocument();
  });

  it("uses aria-label when provided", () => {
    render(<Button aria-label="Fechar janela">×</Button>);
    expect(screen.getByRole("button", { name: "Fechar janela" })).toBeInTheDocument();
  });
});

// ── ThemeToggle ───────────────────────────────────────────────────────────────
describe("ThemeToggle", () => {
  it("shows correct aria-label for light mode", () => {
    render(<ThemeToggle isDark={false} onToggle={jest.fn()} />);
    expect(screen.getByRole("button", { name: /ativar modo escuro/i })).toBeInTheDocument();
  });

  it("shows correct aria-label for dark mode", () => {
    render(<ThemeToggle isDark={true} onToggle={jest.fn()} />);
    expect(screen.getByRole("button", { name: /ativar modo claro/i })).toBeInTheDocument();
  });

  it("sets aria-pressed correctly", () => {
    render(<ThemeToggle isDark={true} onToggle={jest.fn()} />);
    expect(screen.getByRole("button")).toHaveAttribute("aria-pressed", "true");
  });

  it("calls onToggle when clicked", async () => {
    const user = userEvent.setup();
    const onToggle = jest.fn();
    render(<ThemeToggle isDark={false} onToggle={onToggle} />);
    await user.click(screen.getByRole("button"));
    expect(onToggle).toHaveBeenCalledTimes(1);
  });
});
