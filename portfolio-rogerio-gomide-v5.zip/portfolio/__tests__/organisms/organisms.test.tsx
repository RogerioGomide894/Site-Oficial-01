/**
 * @jest-environment jsdom
 */
import React from "react";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import "@testing-library/jest-dom";

jest.mock("@/lib/utils", () => ({ cn: (...c: string[]) => c.filter(Boolean).join(" ") }));
jest.mock("next/link", () => ({
  __esModule: true,
  default: ({ href, children, ...r }: React.AnchorHTMLAttributes<HTMLAnchorElement> & { href: string }) => (
    <a href={href} {...r}>{children}</a>
  ),
}));
jest.mock("next/image", () => ({
  __esModule: true,
  default: (props: React.ImgHTMLAttributes<HTMLImageElement>) => <img {...props} />,
}));
jest.mock("framer-motion", () => ({
  motion: {
    nav: ({ children, ...p }: React.HTMLAttributes<HTMLElement>) => <nav {...p}>{children}</nav>,
    div: ({ children, ...p }: React.HTMLAttributes<HTMLDivElement>) => <div {...p}>{children}</div>,
  },
  AnimatePresence: ({ children }: { children: React.ReactNode }) => <>{children}</>,
}));

import { OfferBar } from "@/components/organisms/OfferBar";
import { MarqueeBar } from "@/components/organisms/MarqueeBar";
import { PainSection } from "@/components/organisms/PainSection";
import { FaqSection } from "@/components/organisms/FaqSection";
import { ServicesSection } from "@/components/organisms/ServicesSection";
import { PortfolioSection } from "@/components/organisms/PortfolioSection";
import { TestimonialsSection } from "@/components/organisms/TestimonialsSection";
import { AboutSection } from "@/components/organisms/AboutSection";

// ── OfferBar ──────────────────────────────────────────────────────────────────
describe("OfferBar", () => {
  it("renders investment text", () => {
    render(<OfferBar />);
    expect(screen.getByText(/R\$ 500/)).toBeInTheDocument();
  });
  it("mentions remote service", () => {
    render(<OfferBar />);
    expect(screen.getByText(/ATENDIMENTO REMOTO/)).toBeInTheDocument();
  });
});

// ── MarqueeBar ────────────────────────────────────────────────────────────────
describe("MarqueeBar", () => {
  it("is hidden from assistive technologies", () => {
    const { container } = render(<MarqueeBar />);
    expect(container.firstChild).toHaveAttribute("aria-hidden", "true");
  });
});

// ── PainSection ───────────────────────────────────────────────────────────────
describe("PainSection", () => {
  it("renders all 3 pain points", () => {
    render(<PainSection />);
    expect(screen.getByText(/depende só de indicação/)).toBeInTheDocument();
    expect(screen.getByText(/não entende exatamente/)).toBeInTheDocument();
    expect(screen.getByText(/O contato acaba virando/)).toBeInTheDocument();
  });
  it("has accessible section heading", () => {
    render(<PainSection />);
    expect(screen.getByRole("heading", { name: /mostra isso/i })).toBeInTheDocument();
  });
});

// ── FaqSection ────────────────────────────────────────────────────────────────
describe("FaqSection", () => {
  it("renders section heading", () => {
    render(<FaqSection />);
    expect(screen.getByRole("heading", { name: /Só o essencial/i })).toBeInTheDocument();
  });
  it("renders all 5 FAQ questions", () => {
    render(<FaqSection />);
    expect(screen.getByText(/Quanto custa uma landing page/)).toBeInTheDocument();
    expect(screen.getByText(/textos e fotos prontos/)).toBeInTheDocument();
    expect(screen.getByText(/celular/)).toBeInTheDocument();
    expect(screen.getByText(/prazo de entrega/)).toBeInTheDocument();
    expect(screen.getByText(/pagamento/)).toBeInTheDocument();
  });
  it("has a CTA link to contact", () => {
    render(<FaqSection />);
    expect(screen.getByRole("link", { name: /fazer uma pergunta/i })).toHaveAttribute("href", "#contato");
  });
});

// ── ServicesSection ───────────────────────────────────────────────────────────
describe("ServicesSection", () => {
  it("renders section heading", () => {
    render(<ServicesSection />);
    expect(screen.getByRole("heading", { name: /vitrine à altura/i })).toBeInTheDocument();
  });
  it("renders all 3 service cards", () => {
    render(<ServicesSection />);
    expect(screen.getByText("Mensagem clara")).toBeInTheDocument();
    expect(screen.getByText("Design que passa confiança")).toBeInTheDocument();
    expect(screen.getByText("Pronta para crescer")).toBeInTheDocument();
  });
  it("renders section CTA link", () => {
    render(<ServicesSection />);
    expect(screen.getByRole("link", { name: /falar do projeto/i })).toHaveAttribute("href", "#contato");
  });
});

// ── AboutSection ──────────────────────────────────────────────────────────────
describe("AboutSection", () => {
  it("renders heading", () => {
    render(<AboutSection />);
    expect(screen.getByRole("heading", { name: /estratégia e propósito/i })).toBeInTheDocument();
  });
  it("renders all 4 stats", () => {
    render(<AboutSection />);
    expect(screen.getByText("12+")).toBeInTheDocument();
    expect(screen.getByText("100%")).toBeInTheDocument();
    expect(screen.getByText("~7 dias")).toBeInTheDocument();
    expect(screen.getByText("2")).toBeInTheDocument();
  });
  it("renders urgency signal text", () => {
    render(<AboutSection />);
    expect(screen.getByText(/vagas abertas este mês/i)).toBeInTheDocument();
  });
  it("has a section landmark", () => {
    render(<AboutSection />);
    expect(screen.getByRole("region", { name: /sobre mim/i })).toBeInTheDocument();
  });
});

// ── PortfolioSection ──────────────────────────────────────────────────────────
describe("PortfolioSection", () => {
  it("renders filter buttons", () => {
    render(<PortfolioSection />);
    expect(screen.getByRole("button", { name: "Todos" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Landing Pages" })).toBeInTheDocument();
  });
  it("shows all 4 cards on initial render", () => {
    render(<PortfolioSection />);
    // 4 cards + 4 lightbox trigger buttons = 8 buttons with aria-label "Ampliar"
    const amplar = screen.getAllByRole("button", { name: /ampliar/i });
    expect(amplar).toHaveLength(4);
  });
  it("filters to landing pages only (2 cards)", async () => {
    const user = userEvent.setup();
    render(<PortfolioSection />);
    await user.click(screen.getByRole("button", { name: "Landing Pages" }));
    expect(screen.getAllByRole("button", { name: /ampliar/i })).toHaveLength(2);
  });
  it("marks active filter with aria-pressed=true", async () => {
    const user = userEvent.setup();
    render(<PortfolioSection />);
    const btn = screen.getByRole("button", { name: "Lojas Virtuais" });
    await user.click(btn);
    expect(btn).toHaveAttribute("aria-pressed", "true");
  });
  it("opens lightbox when a card is clicked", async () => {
    const user = userEvent.setup();
    render(<PortfolioSection />);
    await user.click(screen.getAllByRole("button", { name: /ampliar/i })[0]);
    expect(screen.getByRole("dialog")).toBeInTheDocument();
  });
  it("closes lightbox on close button click", async () => {
    const user = userEvent.setup();
    render(<PortfolioSection />);
    await user.click(screen.getAllByRole("button", { name: /ampliar/i })[0]);
    await user.click(screen.getByRole("button", { name: /fechar visualização/i }));
    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
  });
});

// ── TestimonialsSection ───────────────────────────────────────────────────────
describe("TestimonialsSection", () => {
  it("shows first testimonial by default", () => {
    render(<TestimonialsSection />);
    expect(screen.getByText(/melhor decisão/)).toBeInTheDocument();
  });
  it("shows author avatar initials", () => {
    render(<TestimonialsSection />);
    expect(screen.getByText("CF")).toBeInTheDocument();
  });
  it("advances to next testimonial on next click", async () => {
    const user = userEvent.setup();
    render(<TestimonialsSection />);
    await user.click(screen.getByRole("button", { name: /próximo depoimento/i }));
    expect(screen.getByText(/02 \/ 03/)).toBeInTheDocument();
  });
  it("wraps around to last on prev click from first", async () => {
    const user = userEvent.setup();
    render(<TestimonialsSection />);
    await user.click(screen.getByRole("button", { name: /anterior/i }));
    expect(screen.getByText(/03 \/ 03/)).toBeInTheDocument();
  });
});
