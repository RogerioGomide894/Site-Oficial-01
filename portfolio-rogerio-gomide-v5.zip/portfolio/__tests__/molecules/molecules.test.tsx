/**
 * @jest-environment jsdom
 */
import React from "react";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import "@testing-library/jest-dom";

jest.mock("@/lib/utils", () => ({ cn: (...c: string[]) => c.filter(Boolean).join(" ") }));
jest.mock("next/link", () => ({
  __esModule: true,
  default: ({ href, children, ...r }: React.AnchorHTMLAttributes<HTMLAnchorElement> & { href: string }) => (
    <a href={href} {...r}>{children}</a>
  ),
}));
jest.mock("next/image", () => ({
  __esModule: true,
  default: (props: React.ImgHTMLAttributes<HTMLImageElement>) => <img {...props} />,
}));

import { ServiceCard } from "@/components/molecules/ServiceCard";
import { FaqItem } from "@/components/molecules/FaqItem";
import { TestimonialBlock } from "@/components/molecules/TestimonialBlock";
import { TechCard } from "@/components/molecules/TechCard";
import { NavLink } from "@/components/molecules/NavLink";
import { StatCard } from "@/components/molecules/StatCard";

const MOCK_SERVICE = {
  index: "01", icon: "↗", title: "Mensagem clara",
  description: "Em poucos segundos, o visitante entende.",
  ctaLabel: "Quero essa clareza",
};

const MOCK_FAQ = { question: "Quanto custa?", answer: "A partir de R$ 500." };

const MOCK_TESTIMONIAL = {
  quote: "Ótimo trabalho!",
  author: "João Silva",
  role: "CEO — Empresa X",
  initials: "JS",
  avatarColor: "bg-accent-green",
};

const MOCK_TECH = { symbol: "JS", name: "JavaScript", role: "Interação" };
const MOCK_STAT = { value: "12+", label: "projetos entregues" };

// ── ServiceCard ───────────────────────────────────────────────────────────────
describe("ServiceCard", () => {
  it("renders title and description", () => {
    render(<ServiceCard item={MOCK_SERVICE} />);
    expect(screen.getByText("Mensagem clara")).toBeInTheDocument();
    expect(screen.getByText(/Em poucos segundos/)).toBeInTheDocument();
  });
  it("renders CTA link pointing to #contato by default", () => {
    render(<ServiceCard item={MOCK_SERVICE} />);
    const link = screen.getByRole("link", { name: /quero essa clareza/i });
    expect(link).toHaveAttribute("href", "#contato");
  });
  it("renders as article landmark", () => {
    render(<ServiceCard item={MOCK_SERVICE} />);
    expect(screen.getByRole("article")).toBeInTheDocument();
  });
});

// ── FaqItem ───────────────────────────────────────────────────────────────────
describe("FaqItem", () => {
  it("renders question text", () => {
    render(<FaqItem item={MOCK_FAQ} />);
    expect(screen.getByText("Quanto custa?")).toBeInTheDocument();
  });
  it("renders answer when open", () => {
    render(<FaqItem item={MOCK_FAQ} defaultOpen />);
    expect(screen.getByText("A partir de R$ 500.")).toBeInTheDocument();
  });
  it("is open when defaultOpen=true", () => {
    const { container } = render(<FaqItem item={MOCK_FAQ} defaultOpen />);
    expect(container.querySelector("details")).toHaveAttribute("open");
  });
  it("is closed by default", () => {
    const { container } = render(<FaqItem item={MOCK_FAQ} />);
    expect(container.querySelector("details")).not.toHaveAttribute("open");
  });
});

// ── TestimonialBlock ──────────────────────────────────────────────────────────
describe("TestimonialBlock", () => {
  it("renders quote text", () => {
    render(<TestimonialBlock item={MOCK_TESTIMONIAL} isActive />);
    expect(screen.getByText(/Ótimo trabalho!/)).toBeInTheDocument();
  });
  it("renders author name", () => {
    render(<TestimonialBlock item={MOCK_TESTIMONIAL} isActive />);
    expect(screen.getByText("João Silva")).toBeInTheDocument();
  });
  it("renders author role", () => {
    render(<TestimonialBlock item={MOCK_TESTIMONIAL} isActive />);
    expect(screen.getByText("CEO — Empresa X")).toBeInTheDocument();
  });
  it("renders avatar initials", () => {
    render(<TestimonialBlock item={MOCK_TESTIMONIAL} isActive />);
    expect(screen.getByText("JS")).toBeInTheDocument();
  });
  it("is hidden when not active", () => {
    const { container } = render(<TestimonialBlock item={MOCK_TESTIMONIAL} isActive={false} />);
    expect(container.firstChild).toHaveClass("hidden");
  });
  it("is visible when active", () => {
    const { container } = render(<TestimonialBlock item={MOCK_TESTIMONIAL} isActive />);
    expect(container.firstChild).toHaveClass("block");
  });
});

// ── TechCard ──────────────────────────────────────────────────────────────────
describe("TechCard", () => {
  it("renders tech name", () => {
    render(<TechCard item={MOCK_TECH} index={0} />);
    expect(screen.getByText("JavaScript")).toBeInTheDocument();
  });
  it("renders tech role", () => {
    render(<TechCard item={MOCK_TECH} index={0} />);
    expect(screen.getByText("Interação")).toBeInTheDocument();
  });
  it("renders symbol", () => {
    render(<TechCard item={MOCK_TECH} index={0} />);
    expect(screen.getByText("JS")).toBeInTheDocument();
  });
});

// ── NavLink ───────────────────────────────────────────────────────────────────
describe("NavLink", () => {
  it("renders label text", () => {
    render(<NavLink href="#faq" label="FAQ" />);
    expect(screen.getByRole("link", { name: "FAQ" })).toBeInTheDocument();
  });
  it("points to correct href", () => {
    render(<NavLink href="#portfolio" label="Portfólio" />);
    expect(screen.getByRole("link")).toHaveAttribute("href", "#portfolio");
  });
  it("calls onClick when clicked", async () => {
    const user = userEvent.setup();
    const onClick = jest.fn();
    render(<NavLink href="#" label="Test" onClick={onClick} />);
    await user.click(screen.getByRole("link"));
    expect(onClick).toHaveBeenCalledTimes(1);
  });
});

// ── StatCard ──────────────────────────────────────────────────────────────────
describe("StatCard", () => {
  it("renders the stat value", () => {
    render(<StatCard item={MOCK_STAT} />);
    expect(screen.getByText("12+")).toBeInTheDocument();
  });
  it("renders the stat label", () => {
    render(<StatCard item={MOCK_STAT} />);
    expect(screen.getByText("projetos entregues")).toBeInTheDocument();
  });
});
