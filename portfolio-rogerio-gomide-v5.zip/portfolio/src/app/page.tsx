import { PageTemplate } from "@/components/templates/PageTemplate";
import {
  HeroSection,
  OfferBar,
  MarqueeBar,
  PainSection,
  ServicesSection,
  AboutSection,
  ProcessSection,
  MethodologySection,
  TechSection,
  PortfolioSection,
  TestimonialsSection,
  FaqSection,
  ContactSection,
  FloatingActions,
} from "@/components/organisms";

export default function Home() {
  return (
    <PageTemplate>
      {/* Skip-to-content for keyboard / screen reader users */}
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 focus:z-[100] focus:bg-accent-green focus:text-ink focus:px-4 focus:py-2 focus:rounded"
      >
        Pular para o conteúdo
      </a>

      <HeroSection />
      <OfferBar />
      <MarqueeBar />
      <PainSection />
      <ServicesSection />
      <AboutSection />
      <ProcessSection />
      <MethodologySection />
      <TechSection />
      <PortfolioSection />
      <TestimonialsSection />
      <FaqSection />
      <ContactSection />
      <FloatingActions />
    </PageTemplate>
  );
}
