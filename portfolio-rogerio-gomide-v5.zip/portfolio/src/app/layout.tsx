import type { Metadata } from "next";
import { Manrope, Plus_Jakarta_Sans, DM_Mono } from "next/font/google";
import "@/styles/globals.css";

const manrope = Manrope({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700", "800"],
  variable: "--font-manrope",
  display: "swap",
});

const plusJakarta = Plus_Jakarta_Sans({
  subsets: ["latin"],
  weight: ["600", "700", "800"],
  variable: "--font-jakarta",
  display: "swap",
});

const dmMono = DM_Mono({
  subsets: ["latin"],
  weight: ["400", "500"],
  variable: "--font-mono",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Rogério Gomide — Desenvolvedor Web Full Stack",
  description:
    "Landing pages, sites corporativos e lojas virtuais para divulgar o seu trabalho e transformar visitas em oportunidades. Investimento a partir de R$ 500.",
  metadataBase: new URL("https://rogerio-gomide.com.br"),
  openGraph: {
    title: "Rogério Gomide — Sites que transformam visitas em clientes",
    description:
      "Landing pages, sites corporativos e lojas virtuais. Investimento a partir de R$ 500. Atendimento remoto em todo o Brasil.",
    locale: "pt_BR",
    type: "website",
    images: [
      {
        url: "/og/og-image.png",
        width: 1200,
        height: 630,
        alt: "Rogério Gomide — Desenvolvedor Web Full Stack",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Rogério Gomide — Desenvolvedor Web Full Stack",
    description: "Sites que transformam visitas em clientes. A partir de R$ 500.",
    images: ["/og/og-image.png"],
  },
  robots: {
    index: true,
    follow: true,
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html
      lang="pt-BR"
      className={`${manrope.variable} ${plusJakarta.variable} ${dmMono.variable}`}
    >
      <body>{children}</body>
    </html>
  );
}
