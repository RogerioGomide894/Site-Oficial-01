import { ImageResponse } from "next/og";

export const runtime = "edge";
export const alt = "Rogério Gomide — Desenvolvedor Web Full Stack";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

/** Auto-generated OG image via Next.js built-in support. */
export default async function Image() {
  return new ImageResponse(
    (
      <div
        style={{
          background: "linear-gradient(120deg,#1e3a8a,#273e7c)",
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          alignItems: "flex-start",
          justifyContent: "center",
          padding: "80px",
          fontFamily: "sans-serif",
        }}
      >
        {/* Badge */}
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 32 }}>
          <div style={{ width: 10, height: 10, borderRadius: "50%", background: "#10b981" }} />
          <span style={{ fontFamily: "monospace", fontSize: 14, letterSpacing: 2, color: "#aeb7c8", textTransform: "uppercase" }}>
            Desenvolvedor Web Full Stack
          </span>
        </div>

        {/* Heading */}
        <div style={{ fontSize: 72, fontWeight: 800, color: "#fff", lineHeight: 1, letterSpacing: -4, marginBottom: 28 }}>
          Sites que transformam<br />
          <span style={{ color: "#10b981" }}>visitas em clientes.</span>
        </div>

        {/* Sub */}
        <p style={{ fontSize: 22, color: "#c8d3e8", margin: 0, maxWidth: 600, lineHeight: 1.5 }}>
          Landing pages · Sites corporativos · Lojas virtuais
          <br />A partir de R$ 500 · Pernambuco, Brasil
        </p>

        {/* Avatar */}
        <div
          style={{
            position: "absolute",
            right: 80,
            top: "50%",
            transform: "translateY(-50%)",
            width: 180,
            height: 180,
            borderRadius: "50%",
            background: "#10b981",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: 56,
            fontWeight: 800,
            color: "#fff",
          }}
        >
          RG
        </div>
      </div>
    ),
    { ...size }
  );
}
