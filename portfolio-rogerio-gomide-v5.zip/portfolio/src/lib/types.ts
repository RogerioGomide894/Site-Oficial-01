export interface NavLink {
  href: string;
  label: string;
}

export interface TrustItem {
  strong: string;
  description: string;
}

export interface ServiceItem {
  index: string;
  icon: string;
  title: string;
  description: string;
  ctaLabel: string;
}

export interface IncludeItem {
  index: string;
  title: string;
  description: string;
}

export interface ProcessStep {
  label: string;
  title: string;
  description: string;
}

export interface TechItem {
  symbol: string;
  name: string;
  role: string;
}

export interface PortfolioCard {
  id: string;
  category: "landing" | "store" | "site";
  image: string;
  imageAlt: string;
  badge: string;
  title: string;
  stack: string;
  url?: string;
}

export interface Testimonial {
  quote: string;
  author: string;
  role: string;
  initials: string;
  avatarColor: string;
}

export interface FaqItem {
  question: string;
  answer: string;
}

export interface AudienceItem {
  icon: string;
  title: string;
  description: string;
}

export interface Stat {
  value: string;
  label: string;
}

export type FilterCategory = "all" | "landing" | "store" | "site";
