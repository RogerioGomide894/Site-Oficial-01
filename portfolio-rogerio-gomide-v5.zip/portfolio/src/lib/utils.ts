type ClassValue = string | undefined | null | false;

/** Merges class names, filtering falsy values. DRY replacement for clsx. */
export function cn(...classes: ClassValue[]): string {
  return classes.filter(Boolean).join(" ");
}
