import type {
  NavLink, TrustItem, ServiceItem, ProcessStep,
  TechItem, PortfolioCard, Testimonial, FaqItem, Stat,
} from "./types";

// ── Contatos e marca ───────────────────────────────────────────────────────
export const WA_NUMBER    = "5562991558090";
export const WA_HREF      = `https://wa.me/${WA_NUMBER}`;
export const INSTAGRAM    = "https://www.instagram.com/rogeriogomide.dev";
export const BRAND_NAME   = "rogeriogomide.dev";
export const BRAND_DOMAIN = "rogeriogomide.dev";

// ── Nav ────────────────────────────────────────────────────────────────────
export const NAV_LINKS: NavLink[] = [
  { href: "#servicos",   label: "Serviços"   },
  { href: "#sobre",      label: "Sobre"      },
  { href: "#portfolio",  label: "Portfólio"  },
  { href: "#faq",        label: "FAQ"        },
];

export const TRUST_ITEMS: TrustItem[] = [
  { strong: "Full stack", description: "do design ao código"  },
  { strong: "Mobile",     description: "em primeiro lugar"    },
  { strong: "SEO",        description: "pronto para começar"  },
];

export const STATS: Stat[] = [
  { value: "12+",    label: "projetos entregues"    },
  { value: "100%",   label: "no prazo"              },
  { value: "~7 dias",label: "prazo médio de entrega"},
  { value: "2",      label: "vagas abertas este mês"},
];

export const SERVICES: ServiceItem[] = [
  { index:"01", icon:"↗", title:"Mensagem clara",            description:"Em poucos segundos, o visitante entende o que você oferece e para quem.",                                         ctaLabel:"Quero essa clareza"   },
  { index:"02", icon:"◇", title:"Design que passa confiança",description:"Uma presença profissional que valoriza a sua marca antes da primeira conversa.",                                  ctaLabel:"Quero me destacar"    },
  { index:"03", icon:"⌘", title:"Pronta para crescer",       description:"Rápida, responsiva e estruturada para ser divulgada onde seu público está.",                                      ctaLabel:"Quero ir para a web"  },
];

export const PROCESS_STEPS: ProcessStep[] = [
  { label:"01 / BRIEFING",   title:"Você conta",       description:"Fala sobre o seu negócio, seu público e o resultado que busca."                    },
  { label:"02 / ESTRATÉGIA", title:"Nós organizamos",  description:"Transformamos suas informações em uma mensagem fácil de entender."                  },
  { label:"03 / BUILD",      title:"Nós construímos",  description:"Desenvolvemos uma página bonita, rápida e pensada para qualquer tela."              },
  { label:"04 / PUBLICAÇÃO", title:"Você divulga",     description:"Recebe uma presença digital pronta para começar a atrair oportunidades."            },
];

export const METHODOLOGY_STEPS: ProcessStep[] = [
  { label:"01", title:"Briefing",      description:"Entendemos negócio, objetivos e público."              },
  { label:"02", title:"Direção",       description:"Definimos mensagem, estrutura e visual."               },
  { label:"03", title:"Desenvolvimento",description:"Transformamos a estratégia em uma experiência web."   },
  { label:"04", title:"Entrega",       description:"Revisamos, testamos e deixamos tudo pronto."           },
];

export const TECHNOLOGIES: TechItem[] = [
  { symbol:"</>", name:"HTML",       role:"Estrutura"  },
  { symbol:"✦",   name:"CSS",        role:"Interface"  },
  { symbol:"JS",  name:"JavaScript", role:"Interação"  },
  { symbol:"PHP", name:"PHP",        role:"Integração" },
  { symbol:"Py",  name:"Python",     role:"Automação"  },
];

// ── Portfólio — imagens originais do arquivo zip ──────────────────────────
export const PORTFOLIO_CARDS: PortfolioCard[] = [
  {
    id:"p1", category:"landing",
    image:"https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=1100&q=80",
    imageAlt:"Dashboard com gráficos de consultoria digital — landing page desenvolvida para consultoria de negócios",
    badge:"MODELO / LANDING PAGE", title:"Consultoria digital", stack:"HTML · CSS · JavaScript · SEO",
  },
  {
    id:"p2", category:"store",
    image:"https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?auto=format&fit=crop&w=1100&q=80",
    imageAlt:"Interface de loja virtual com produtos em destaque — e-commerce desenvolvido para marca de produtos",
    badge:"MODELO / LOJA VIRTUAL", title:"Marca de produtos", stack:"HTML · CSS · JavaScript · PHP",
  },
  {
    id:"p3", category:"site",
    image:"https://images.unsplash.com/photo-1553877522-43269d4ea984?auto=format&fit=crop&w=1100&q=80",
    imageAlt:"Site corporativo moderno com layout profissional — desenvolvido para empresa de serviços B2B",
    badge:"MODELO / SITE CORPORATIVO", title:"Empresa de serviços", stack:"HTML · CSS · PHP · SEO",
  },
  {
    id:"p4", category:"landing",
    image:"https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&w=1100&q=80",
    imageAlt:"Landing page para especialista autônomo com foco em conversão e clareza da proposta de valor",
    badge:"MODELO / LANDING PAGE", title:"Especialista autônomo", stack:"HTML · CSS · JavaScript",
  },
];

export const TESTIMONIALS: Testimonial[] = [
  { quote:"Contratar a RC WEB STUDIO para criar o novo site da nossa empresa foi a melhor decisão. O projeto foi entregue no prazo, o design ficou moderno e nossos clientes adoraram a facilidade de navegação. Recomendo muito o trabalho!", author:"Cinthiany Fernandes", role:"Gerente — Studio de Beleza Cinthiany Fernandes", initials:"CF", avatarColor:"bg-mint" },
  { quote:"Profissionalismo, atenção aos detalhes e uma comunicação muito fácil durante todo o projeto. Entregou exatamente o que precisávamos.", author:"Marcos Oliveira", role:"Sócio — Consultoria MO", initials:"MO", avatarColor:"bg-navy" },
  { quote:"A nova página deixou nossa apresentação muito mais clara e profissional. Em duas semanas já sentimos diferença no número de contatos.", author:"Ana Paula Ramos", role:"Proprietária — Clínica Ramos", initials:"AR", avatarColor:"bg-[#3b2f8f]" },
];

export const FAQ_ITEMS: FaqItem[] = [
  { question:"Quanto custa uma landing page?",    answer:"O investimento inicial é de R$ 500. O valor final depende do conteúdo, recursos e nível de personalização do projeto."                               },
  { question:"Preciso ter textos e fotos prontos?",answer:"Não. Você chega com o que tem; nós ajudamos a organizar a mensagem e indicar o que será necessário para uma boa apresentação."                     },
  { question:"Vai funcionar bem no celular?",     answer:"Sim. Cada página é desenvolvida para telas pequenas e grandes, porque boa parte dos seus visitantes chegará pelo celular."                          },
  { question:"Qual o prazo de entrega?",          answer:"Em média 7 dias úteis para uma landing page. Sites corporativos e lojas virtuais têm prazos específicos definidos no briefing."                     },
  { question:"Como funciona o pagamento?",        answer:"50% no início do projeto e 50% na entrega. Aceito Pix, transferência bancária e cartão de crédito."                                                 },
];

export const SOCIAL_LINKS = [
  { label:"Instagram", href:"https://www.instagram.com/rogeriogomide.dev", external: true },
  { label:"GitHub",    href:"https://github.com/RogerioGomide894",          external: true },
  { label:"LinkedIn",  href:"https://linkedin.com/in/rogerio-gomide-45a626346", external: true },
];
