"use client";

import { useEffect, useState } from "react";
import { Header } from "@/components/organisms";

interface PageTemplateProps { children: React.ReactNode; }

export function PageTemplate({ children }: PageTemplateProps) {
  const [isDark, setIsDark] = useState(false);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", isDark);
  }, [isDark]);

  // Scroll reveal
  useEffect(() => {
    const els = document.querySelectorAll<HTMLElement>(".reveal-section");
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.07 }
    );
    els.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  return (
    <>
      <div aria-hidden="true" className="noise-overlay" />
      <Header isDark={isDark} onToggleTheme={() => setIsDark((d) => !d)} />
      {/* padding-top = altura da nav fixa (96px) */}
      <main id="main-content" className="pt-24">
        {children}
      </main>
    </>
  );
}
