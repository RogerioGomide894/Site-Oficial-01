export function OfferBar() {
  return (
    <div className="bg-mint text-navy-DEFAULT py-3.5">
      <div className="container mx-auto px-6 max-w-[1180px] flex flex-wrap justify-between items-center gap-3 font-mono text-[10px] tracking-wider font-semibold text-[#0b1e4a]">
        <span>LANDING PAGES · SITES CORPORATIVOS · LOJAS VIRTUAIS</span>
        <strong className="text-[12px]">INVESTIMENTO INICIAL A PARTIR DE R$ 500</strong>
        <span>ATENDIMENTO REMOTO EM TODO O BRASIL</span>
      </div>
    </div>
  );
}
