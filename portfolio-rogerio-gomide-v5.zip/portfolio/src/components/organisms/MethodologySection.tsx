import { Eyebrow, Heading, Button } from "@/components/atoms";
import { METHODOLOGY_STEPS } from "@/lib/data";

export function MethodologySection() {
  return (
    <section id="metodologia" aria-labelledby="methodology-heading"
      className="reveal-section py-[clamp(60px,10vw,130px)] bg-white">
      <div className="container mx-auto px-6 max-w-[1180px]">
        <Eyebrow variant="light">Metodologia de trabalho</Eyebrow>
        <div className="flex flex-col md:flex-row justify-between md:items-end gap-8 mb-14">
          <Heading as="h2" size="md" id="methodology-heading" accentColor="navy">
            O projeto avança<br />com <em>clareza em cada etapa.</em>
          </Heading>
          <p className="max-w-[340px] text-ink-muted text-[14px] leading-[1.7] m-0">
            Sem surpresas e sem etapas escondidas. Você acompanha a evolução da
            primeira conversa até a entrega final.
          </p>
        </div>
        <ol className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 border-t border-line list-none p-0 m-0 gap-10 md:gap-0">
          {METHODOLOGY_STEPS.map((step, i) => (
            <li key={step.label}
              className={`pt-7 ${i > 0 ? "md:pl-6" : ""} ${i < METHODOLOGY_STEPS.length - 1 ? "md:pr-6 md:border-r md:border-line" : ""}`}>
              <span className="grid place-items-center w-7 h-7 bg-mint text-white rounded-full font-mono text-[9px] -mt-[38px] mb-0 font-semibold">
                {step.label}
              </span>
              <h3 className="font-display font-extrabold text-[18px] tracking-[-0.02em] mt-7 mb-2 text-ink">{step.title}</h3>
              <p className="text-ink-muted text-[13px] leading-relaxed max-w-[180px] m-0">{step.description}</p>
            </li>
          ))}
        </ol>
        <div className="mt-14 flex flex-col sm:flex-row items-start sm:items-center gap-5">
          <Button href="#contato" variant="primary" className="text-[11px] px-4 py-2.5">
            Começar meu projeto agora ↘
          </Button>
          <p className="text-ink-muted text-[12px] m-0">Sem compromisso — você decide depois de conversar.</p>
        </div>
      </div>
    </section>
  );
}
