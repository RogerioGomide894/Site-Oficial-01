import { Button, Eyebrow, Heading, InlineLink } from "@/components/atoms";
import { WA_HREF } from "@/lib/data";
import { TRUST_ITEMS } from "@/lib/data";

export function HeroSection() {
  return (
    <section
      id="inicio"
      aria-labelledby="hero-heading"
      className="relative min-h-[100dvh] flex items-center overflow-hidden bg-navy"
    >
      {/* ── Hero background video ── */}
      <div
        aria-hidden="true"
        className="absolute inset-0 z-0 overflow-hidden"
      >
        <video
          autoPlay muted loop playsInline
          preload="metadata"
          className="w-full h-full object-cover opacity-[0.18] saturate-[1.2] brightness-75"
        >
          <source src="https://player.vimeo.com/external/371433846.sd.mp4?s=236da2f3c0fd273d2c6d9a064f3ae35579b2bbba&profile_id=139&oauth2_token_id=57447761" type="video/mp4" />
          <source src="https://cdn.pixabay.com/video/2022/10/01/133167-754802478_large.mp4" type="video/mp4" />
        </video>
        {/* Dark gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-br from-navy/92 via-navy/75 to-navy/88" />
      </div>
      {/* Aurora blobs */}
      <div aria-hidden="true" className="aurora w-[500px] h-[500px] bg-mint       left-[-200px] top-[-100px]" />
      <div aria-hidden="true" className="aurora w-[400px] h-[400px] bg-navy-mid   right-[-120px] bottom-[0px]" />
      <div aria-hidden="true" className="aurora w-[300px] h-[300px] bg-mint       right-[30%]   top-[10%] opacity-[0.08]" />

      {/* Noise overlay */}
      <div aria-hidden="true" className="noise-overlay" />

      <div className="relative z-10 container mx-auto px-6 max-w-[1180px] grid grid-cols-1 md:grid-cols-2 gap-10 items-center py-32 md:py-0">
        {/* Copy */}
        <div>
          <p className="font-mono text-[10px] font-medium tracking-[2px] text-mint mb-5 uppercase flex items-center gap-2">
            <span className="inline-block w-1.5 h-1.5 rounded-full bg-mint animate-pulse" aria-hidden="true" />
            Disponível para novos projetos
          </p>
          <Eyebrow variant="dark">Desenvolvedor web sênior · full stack</Eyebrow>

          <Heading as="h1" size="xl" id="hero-heading" accentColor="white-mint" className="text-white">
            Transformo visitantes<br />em <em>clientes.</em>
          </Heading>

          <p className="max-w-[480px] text-[16px] leading-[1.7] text-white/65 mt-7 mb-0">
            <strong className="text-white/90 font-semibold">Seu site pode fazer isso hoje.</strong>{" "}
            Desenvolvo landing pages, sites corporativos e lojas virtuais com estratégia,
            design e código para tornar seu negócio mais fácil de encontrar e escolher.
          </p>

          <div className="flex flex-col xs:flex-row items-start xs:items-center gap-4 mt-9">
            <Button href={WA_HREF} variant="primary" external>
              Quero transformar meu site <span className="text-white/70">↘</span>
            </Button>
            <InlineLink href="#portfolio" className="text-white/60 hover:text-white">
              Ver projetos
            </InlineLink>
          </div>

          {/* Trust bar */}
          <ul className="flex gap-7 mt-14 list-none p-0 m-0 flex-wrap" aria-label="Diferenciais">
            {TRUST_ITEMS.map((t, i) => (
              <li
                key={t.strong}
                className={`grid gap-0.5 ${i < TRUST_ITEMS.length - 1 ? "pr-7 border-r border-white/15" : ""}`}
              >
                <strong className="font-mono text-[12px] text-white/90">{t.strong}</strong>
                <span className="text-[10px] text-white/45">{t.description}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Hero art — browser mockup */}
        <div className="relative min-h-[440px] grid place-items-center" aria-label="Prévia de um site profissional">
          {/* Orbit rings */}
          <div aria-hidden="true" className="orbit-ring absolute w-[480px] h-[480px]" />
          <div aria-hidden="true" className="orbit-ring absolute w-[600px] h-[310px] rotate-[-38deg]" />

          {/* Browser */}
          <div className="float-card w-full max-w-[490px] rounded-2xl bg-white/10 backdrop-blur-sm p-2 shadow-float relative z-10 border border-white/10">
            {/* Chrome */}
            <div className="h-7 flex items-center justify-between font-mono text-[8px] px-2 text-white/40">
              <div className="flex gap-1" aria-hidden="true">
                {["bg-red-400/60","bg-yellow-400/60","bg-green-400/60"].map((c,i) => (
                  <span key={i} className={`w-[5px] h-[5px] rounded-full ${c}`} />
                ))}
              </div>
              <span className="bg-white/10 px-3 py-0.5 rounded-full">seunegocio.com.br</span>
              <span className="text-mint text-[7px]">● LIVE</span>
            </div>

            {/* Screen */}
            <div className="h-[295px] rounded-lg overflow-hidden" style={{ background: "linear-gradient(135deg,#e5e3fb 0%,#d4cfff 100%)" }}>
              <div className="p-4">
                <div className="flex justify-between text-[7px] mb-3">
                  <strong className="text-[12px] font-display font-extrabold text-[#3d2e9c]">nora.</strong>
                  <span className="text-[#6b5fc8] font-mono text-[7px]">sobre · projetos · contato</span>
                </div>
                <div className="flex items-center justify-between mt-2">
                  <div>
                    <small className="font-mono text-[8px] tracking-[1px] text-[#6b5fc8]">ESTÚDIO CRIATIVO</small>
                    <h2 className="font-display font-extrabold text-[32px] leading-[0.95] tracking-[-2px] text-[#1a1060] mt-1">
                      Ideias que<br /><span className="text-[#4f3abf]">ganham forma.</span>
                    </h2>
                    <a className="text-[8px] font-extrabold text-[#4f3abf] mt-2 block">Conheça o estúdio ↗</a>
                  </div>
                  <div
                    aria-hidden="true"
                    className="w-[140px] h-[140px] rounded-full relative flex-shrink-0"
                    style={{ background: "linear-gradient(140deg,#baacff,#6847ff 50%,#2f1b9d)", boxShadow: "inset -14px -18px 25px #22147a55" }}
                  >
                    {[14,35,56].map((inset,i) => (
                      <span key={i} style={{ inset }} className={`absolute rounded-full border border-white/30 ${i===2?"bg-mint/80 border-0":""}`} />
                    ))}
                  </div>
                </div>
                <div className="flex justify-between font-mono text-[7px] text-[#6b5fc8] mt-3">
                  <span>01 / 03</span><span>UMA NOVA PERSPECTIVA</span>
                </div>
              </div>
            </div>

            <div className="font-mono text-[7px] tracking-wider px-2 pt-2 pb-1 flex justify-between text-white/40">
              <span>LANDING PAGE</span><span>DESIGN & DEV</span>
            </div>
          </div>

          {/* Floating badge */}
          <div
            aria-hidden="true"
            className="float-card-delayed absolute z-20 right-[-18px] bottom-8 bg-mint rounded-xl p-3.5 shadow-float text-[10px] leading-[1.5] flex gap-2 max-w-[170px]"
          >
            <span className="text-[16px]">✦</span>
            <p className="m-0 text-navy font-semibold"><strong className="font-extrabold">Uma presença digital</strong><br />feita para ser lembrada.</p>
          </div>
        </div>
      </div>

      {/* Scroll hint */}
      <div
        aria-hidden="true"
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-white/30 text-[10px] font-mono tracking-[1px]"
      >
        <span>ROLE PARA DESCOBRIR</span>
        <span className="animate-bounce text-base">↓</span>
      </div>
    </section>
  );
}
