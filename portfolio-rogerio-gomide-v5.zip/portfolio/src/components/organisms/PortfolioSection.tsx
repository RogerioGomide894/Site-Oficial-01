"use client";

import { useState } from "react";
import Image from "next/image";
import { Eyebrow, Heading, Button } from "@/components/atoms";
import { PortfolioCard } from "@/components/molecules";
import { PORTFOLIO_CARDS } from "@/lib/data";
import type { FilterCategory, PortfolioCard as PortfolioCardType } from "@/lib/types";

const FILTERS: { label: string; value: FilterCategory }[] = [
  { label: "Todos",            value: "all" },
  { label: "Landing Pages",   value: "landing" },
  { label: "Lojas Virtuais",  value: "store" },
  { label: "Sites Corporativos", value: "site" },
];

export function PortfolioSection() {
  const [active, setActive]     = useState<FilterCategory>("all");
  const [lightbox, setLightbox] = useState<PortfolioCardType | null>(null);

  const visible = PORTFOLIO_CARDS.filter((c) => active === "all" || c.category === active);

  return (
    <section id="portfolio" aria-labelledby="portfolio-heading"
      className="reveal-section py-[clamp(60px,10vw,130px)] bg-white">
      <div className="container mx-auto px-6 max-w-[1180px]">
        <Eyebrow variant="light">Portfólio e possibilidades</Eyebrow>
        <Heading as="h2" size="md" id="portfolio-heading" accentColor="navy">
          Apresente o seu negócio<br />de um jeito <em>impossível de ignorar.</em>
        </Heading>
        <p className="text-ink-muted text-[14px] leading-relaxed mt-4 mb-0 max-w-[520px]">
          Exemplos de formatos de projeto. Substitua pelas capturas dos seus trabalhos
          publicados para fortalecer a prova social.
        </p>

        {/* Filtros */}
        <div role="group" aria-label="Filtrar projetos" className="flex flex-wrap gap-2 mt-8 mb-6">
          {FILTERS.map(({ label, value }) => (
            <button key={value} type="button"
              onClick={() => setActive(value)}
              aria-pressed={active === value}
              className={`border rounded-full text-[11px] font-semibold px-4 py-2 min-h-[36px] cursor-pointer transition-all focus-ring ${
                active === value
                  ? "bg-navy border-navy text-white"
                  : "border-line bg-transparent text-ink-muted hover:border-navy hover:text-navy"
              }`}
            >{label}</button>
          ))}
        </div>

        {/* Grid desktop / carrossel snap mobile */}
        <div className="hidden sm:grid sm:grid-cols-2 gap-4" aria-live="polite" aria-label="Projetos">
          {visible.map((card) => (
            <button key={card.id} type="button" onClick={() => setLightbox(card)}
              className="w-full text-left focus-ring rounded-xl" aria-label={`Ampliar: ${card.title}`}>
              <PortfolioCard item={card} />
            </button>
          ))}
        </div>

        {/* Mobile: horizontal snap scroll */}
        <div className="sm:hidden flex gap-4 overflow-x-auto snap-x-mandatory pb-3 -mx-6 px-6"
          aria-label="Projetos do portfólio" aria-live="polite">
          {visible.map((card) => (
            <button key={card.id} type="button" onClick={() => setLightbox(card)}
              className="snap-start flex-shrink-0 w-[82vw] text-left focus-ring rounded-xl"
              aria-label={`Ampliar: ${card.title}`}>
              <PortfolioCard item={card} />
            </button>
          ))}
        </div>

        <div className="mt-10 flex flex-col sm:flex-row items-start sm:items-center gap-5 pt-8 border-t border-line">
          <p className="text-ink-muted text-[13px] m-0">Quer um projeto como esses?</p>
          <Button href="#contato" variant="primary" className="text-[11px] px-4 py-2.5">Vamos conversar ↗</Button>
        </div>
      </div>

      {/* Lightbox */}
      {lightbox && (
        <div role="dialog" aria-modal="true" aria-label={`Visualizando: ${lightbox.title}`}
          className="fixed inset-0 z-50 bg-navy/95 flex flex-col items-center justify-center p-8"
          onClick={() => setLightbox(null)}>
          <button type="button" onClick={() => setLightbox(null)} aria-label="Fechar visualização"
            className="absolute top-5 right-6 text-white text-[36px] bg-transparent border-0 cursor-pointer focus-ring leading-none">×</button>
          <div className="relative max-h-[78vh] w-full max-w-[900px]" onClick={(e) => e.stopPropagation()}>
            <Image src={lightbox.image} alt={lightbox.imageAlt} width={1100} height={700}
              className="rounded-xl object-contain w-full h-auto" />
            <p className="text-white/60 text-[11px] text-center mt-3 font-mono">
              {lightbox.badge} — {lightbox.title}
            </p>
          </div>
        </div>
      )}
    </section>
  );
}
