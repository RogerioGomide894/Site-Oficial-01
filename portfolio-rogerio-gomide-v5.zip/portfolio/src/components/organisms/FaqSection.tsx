import { Eyebrow, Heading, Button } from "@/components/atoms";
import { FaqItem } from "@/components/molecules";
import { FAQ_ITEMS } from "@/lib/data";

export function FaqSection() {
  return (
    <section id="faq" aria-labelledby="faq-heading"
      className="reveal-section py-[clamp(60px,10vw,130px)] bg-paper">
      <div className="container mx-auto px-6 max-w-[1180px]">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
          <div>
            <Eyebrow variant="light">Dúvidas frequentes</Eyebrow>
            <Heading as="h2" size="md" id="faq-heading" accentColor="navy">
              Sem letras miúdas.<br /><em>Só o essencial.</em>
            </Heading>
            <p className="text-ink-muted text-[14px] leading-relaxed mt-6 mb-8 max-w-[280px]">
              Não encontrou sua dúvida? Manda uma mensagem e respondo em até 24h.
            </p>
            <Button href="#contato" variant="primary" className="text-[11px] px-4 py-2.5">
              Fazer uma pergunta ↗
            </Button>
          </div>
          <div className="border-t border-line">
            {FAQ_ITEMS.map((item, i) => (
              <FaqItem key={item.question} item={item} defaultOpen={i === 0} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
