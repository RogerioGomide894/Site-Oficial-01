import { Eyebrow, Heading, Button } from "@/components/atoms";
import { TechCard } from "@/components/molecules";
import { TECHNOLOGIES } from "@/lib/data";

export function TechSection() {
  return (
    <section id="tecnologias" aria-labelledby="tech-heading"
      className="reveal-section py-[clamp(60px,10vw,120px)] bg-mint-faint">
      <div className="container mx-auto px-6 max-w-[1180px]">
        <Eyebrow className="text-mint-dark [&>span]:bg-mint-dark">Tecnologias e habilidades</Eyebrow>
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <Heading as="h2" size="md" id="tech-heading" accentColor="navy">
            Ferramentas que dão<br /><em>vida à sua ideia.</em>
          </Heading>
          <Button href="#contato" variant="outline" className="self-start md:self-end text-[11px] px-4 py-2.5">
            Falar do projeto ↗
          </Button>
        </div>
        <ul className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3.5 list-none p-0 m-0">
          {TECHNOLOGIES.map((tech, i) => <li key={tech.name}><TechCard item={tech} index={i} /></li>)}
        </ul>
      </div>
    </section>
  );
}
