import { Eyebrow, Heading } from "@/components/atoms";

const PAIN_POINTS = [
  "Você depende só de indicação ou de posts espalhados nas redes.",
  "Quem visita seu perfil ainda não entende exatamente o que você faz.",
  "O contato acaba virando esforço, em vez de ser o próximo passo natural.",
];

export function PainSection() {
  return (
    <section
      aria-labelledby="pain-heading"
      className="reveal-section py-[clamp(60px,10vw,130px)] bg-paper"
    >
      <div className="container mx-auto px-6 max-w-[1180px] grid grid-cols-1 md:grid-cols-2 gap-16 items-start">
        <div>
          <Eyebrow variant="light">Isso parece familiar?</Eyebrow>
          <Heading as="h2" size="md" id="pain-heading" accentColor="navy">
            Seu trabalho é bom.<br />Mas a web ainda não <em>mostra isso.</em>
          </Heading>
        </div>
        <ol className="list-none p-0 m-0 flex flex-col gap-6">
          {PAIN_POINTS.map((point, i) => (
            <li key={i} className="flex items-start gap-4 pb-6 border-b border-line last:border-0 last:pb-0">
              <span aria-hidden="true" className="font-mono text-[11px] text-mint font-semibold flex-shrink-0 mt-0.5 w-5">
                0{i + 1}
              </span>
              <p className="text-[15px] leading-relaxed text-ink-muted m-0">{point}</p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
