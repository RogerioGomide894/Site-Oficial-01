import { Eyebrow, Heading, Button } from "@/components/atoms";
import { ServiceCard } from "@/components/molecules";
import { SERVICES } from "@/lib/data";

export function ServicesSection() {
  return (
    <section id="servicos" aria-labelledby="services-heading"
      className="reveal-section py-[clamp(60px,10vw,130px)] bg-white">
      <div className="container mx-auto px-6 max-w-[1180px]">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-14">
          <div>
            <Eyebrow variant="light">A solução certa</Eyebrow>
            <Heading as="h2" size="md" id="services-heading" accentColor="navy">
              Seu trabalho merece<br /><em>uma vitrine à altura.</em>
            </Heading>
          </div>
          <p className="self-end max-w-[400px] text-ink-muted text-[15px] leading-[1.7] m-0">
            Você não precisa de mais um link perdido nas redes sociais. Precisa de
            uma página que explique o que faz, por que escolher você e como entrar em contato.
          </p>
        </div>

        <ul className="grid grid-cols-1 md:grid-cols-3 gap-4 list-none p-0 m-0">
          {SERVICES.map((s) => <li key={s.index}><ServiceCard item={s} /></li>)}
        </ul>

        <div className="flex items-center gap-5 mt-10 pt-8 border-t border-line">
          <p className="text-ink-muted text-[13px] m-0">Pronto para dar o próximo passo?</p>
          <Button href="#contato" variant="primary" className="text-[11px] px-4 py-2.5">
            Falar do projeto ↗
          </Button>
        </div>
      </div>
    </section>
  );
}
