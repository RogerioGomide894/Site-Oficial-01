import { Eyebrow, Heading } from "@/components/atoms";
import { ProcessStep } from "@/components/molecules";
import { PROCESS_STEPS } from "@/lib/data";

export function ProcessSection() {
  return (
    <section id="processo" aria-labelledby="process-heading"
      className="bg-navy text-white py-[clamp(60px,10vw,120px)]">
      <div className="container mx-auto px-6 max-w-[1180px]">
        <Eyebrow variant="dark">Processo sem ruído</Eyebrow>
        <Heading as="h2" size="lg" id="process-heading" accentColor="white-mint" className="text-white">
          Você não precisa<br />saber <em>por onde começar.</em>
        </Heading>
        <ol className="grid grid-cols-1 md:grid-cols-4 mt-16 border-t border-white/10 list-none p-0 m-0">
          {PROCESS_STEPS.map((step, i) => (
            <li key={step.label} className={i > 0 ? "md:pl-6" : ""}>
              <ProcessStep step={step} isLast={i === PROCESS_STEPS.length - 1} theme="dark" />
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
