import { Eyebrow, Heading } from "@/components/atoms";
import { StatCard } from "@/components/molecules";
import { STATS } from "@/lib/data";

export function AboutSection() {
  return (
    <section id="sobre" aria-labelledby="about-heading"
      className="reveal-section bg-navy-DEFAULT text-white py-[clamp(60px,10vw,120px)]"
      style={{ background: "#0b1e4a" }}>
      <div className="container mx-auto px-6 max-w-[1180px] grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
        <div>
          <Eyebrow variant="dark">Sobre mim</Eyebrow>
          <Heading as="h2" size="md" id="about-heading" accentColor="white-mint" className="text-white">
            Código com<br /><em>estratégia e propósito.</em>
          </Heading>
          <div className="flex items-start gap-5 mt-8">
            <div aria-hidden="true"
              className="flex-shrink-0 w-16 h-16 rounded-full bg-mint grid place-items-center font-display font-extrabold text-[20px] text-white">
              RG
            </div>
            <div>
              <p className="text-[15px] leading-[1.75] text-white/65 m-0">
                Sou Rogério Gomide, desenvolvedor web full stack baseado em Pernambuco.
                Trabalho com negócios que querem transformar sua presença digital em um
                ativo real — não apenas um endereço na internet.
              </p>
              <p className="text-[15px] leading-[1.75] text-white/65 mt-4 mb-0">
                Cada projeto começa pela estratégia: entender o público, organizar a
                mensagem e construir uma experiência que converte visitantes em clientes.
              </p>
            </div>
          </div>
        </div>
        <div>
          <ul className="grid grid-cols-2 gap-x-10 gap-y-10 border-t border-white/10 pt-10 list-none p-0 m-0">
            {STATS.map((stat) => <li key={stat.label}><StatCard item={stat} /></li>)}
          </ul>
          <div className="mt-10 flex items-start gap-3 bg-white/5 border border-white/10 rounded-xl p-4">
            <span aria-hidden="true" className="text-mint text-lg flex-shrink-0 mt-0.5">●</span>
            <p className="m-0 text-[13px] text-white/65 leading-relaxed">
              <strong className="text-white">Agenda com 2 vagas abertas este mês.</strong>{" "}
              Se você está planejando um projeto, é um bom momento para conversar antes
              que o calendário feche.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
