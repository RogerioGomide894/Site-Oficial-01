"use client";
import { useEffect, useState } from "react";
import { WA_HREF } from "@/lib/data";

export function FloatingActions() {
  const [showTop, setShowTop] = useState(false);
  useEffect(() => {
    const onScroll = () => setShowTop(window.scrollY > 300);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  return (
    <>
      <a href={WA_HREF} target="_blank" rel="noopener noreferrer" aria-label="Falar no WhatsApp"
        className="fixed bottom-5 right-5 z-50 bg-mint text-navy font-extrabold text-[11px] px-4 py-2.5 rounded-full shadow-float no-underline flex items-center gap-1.5 hover:bg-mint-dark hover:text-white transition-all focus-ring">
        <span aria-hidden="true">●</span><span className="hidden sm:inline">WhatsApp</span>
      </a>
      <a href="#inicio" aria-label="Voltar ao topo"
        className={`fixed bottom-[68px] right-5 z-50 w-10 h-10 grid place-items-center bg-navy text-white rounded-full shadow-float no-underline transition-all duration-300 hover:bg-mint hover:text-navy focus-ring ${showTop?"opacity-100 pointer-events-auto translate-y-0":"opacity-0 pointer-events-none translate-y-2"}`}>↑</a>
    </>
  );
}
