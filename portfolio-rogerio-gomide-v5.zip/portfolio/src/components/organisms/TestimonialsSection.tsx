"use client";

import { useState } from "react";
import { Eyebrow } from "@/components/atoms";
import { TestimonialBlock } from "@/components/molecules";
import { TESTIMONIALS } from "@/lib/data";

export function TestimonialsSection() {
  const [current, setCurrent] = useState(0);
  const total = TESTIMONIALS.length;

  const prev = () => setCurrent((c) => (c - 1 + total) % total);
  const next = () => setCurrent((c) => (c + 1) % total);

  return (
    <section className="bg-navy text-white py-[clamp(60px,10vw,110px)]" aria-label="Depoimentos de clientes">
      <div className="container mx-auto px-6 max-w-[1180px]">
        <Eyebrow variant="dark">Depoimentos</Eyebrow>
        <div role="region" aria-roledescription="carrossel" aria-label="Depoimentos">
          {TESTIMONIALS.map((t, i) => (
            <TestimonialBlock key={i} item={t} isActive={i === current} />
          ))}
        </div>
        <div className="flex gap-3 items-center mt-8">
          <button type="button" onClick={prev} aria-label="Depoimento anterior"
            className="border border-white/20 text-white bg-transparent w-10 h-10 rounded-full cursor-pointer hover:bg-white/10 hover:border-white/40 transition-all text-[15px] focus-ring">←</button>
          <span aria-live="polite" aria-atomic="true" className="font-mono text-[10px] text-white/40 min-w-[40px] text-center">
            {String(current + 1).padStart(2,"0")} / {String(total).padStart(2,"0")}
          </span>
          <button type="button" onClick={next} aria-label="Próximo depoimento"
            className="border border-white/20 text-white bg-transparent w-10 h-10 rounded-full cursor-pointer hover:bg-white/10 hover:border-white/40 transition-all text-[15px] focus-ring">→</button>
        </div>
      </div>
    </section>
  );
}
