"use client";

import { useState, useEffect, useCallback } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Logo, Button, ThemeToggle } from "@/components/atoms";
import { NavLink } from "@/components/molecules";
import { NAV_LINKS } from "@/lib/data";

interface HeaderProps {
  isDark: boolean;
  onToggleTheme: () => void;
}

export function Header({ isDark, onToggleTheme }: HeaderProps) {
  const [menuOpen, setMenuOpen]       = useState(false);
  const [scrolled, setScrolled]       = useState(false);
  const [progress, setProgress]       = useState(0);
  const [activeSection, setActiveSection] = useState("");

  const closeMenu = () => setMenuOpen(false);

  // Scroll progress + sticky shadow
  useEffect(() => {
    const onScroll = () => {
      const scrolled = window.scrollY;
      const total    = document.body.scrollHeight - window.innerHeight;
      setScrolled(scrolled > 10);
      setProgress(total > 0 ? (scrolled / total) * 100 : 0);
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Active section via IntersectionObserver
  const updateActive = useCallback(() => {
    const ids = NAV_LINKS.map((l) => l.href.replace("#", ""));
    for (const id of [...ids].reverse()) {
      const el = document.getElementById(id);
      if (el && el.getBoundingClientRect().top <= 120) {
        setActiveSection(id);
        return;
      }
    }
    setActiveSection("");
  }, []);

  useEffect(() => {
    window.addEventListener("scroll", updateActive, { passive: true });
    return () => window.removeEventListener("scroll", updateActive);
  }, [updateActive]);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        scrolled ? "bg-white/95 backdrop-blur-md shadow-sm" : "bg-transparent"
      }`}
    >
      <div className="flex items-center justify-between h-24 px-6 max-w-[1180px] mx-auto">
        <Logo />

        {/* Desktop nav */}
        <nav id="main-nav" aria-label="Navegação principal" className="hidden md:flex gap-8">
          {NAV_LINKS.map((link) => (
            <NavLink
              key={link.href}
              href={link.href}
              label={link.label}
              isActive={activeSection === link.href.replace("#", "")}
            />
          ))}
        </nav>

        <div className="flex items-center gap-2.5">
          <ThemeToggle isDark={isDark} onToggle={onToggleTheme} />
          <Button href="#contato" className="hidden md:inline-flex text-[11px] px-4 py-2.5">
            Falar do projeto <span className="text-white/70 ml-0.5">↗</span>
          </Button>
          <button
            type="button"
            aria-label={menuOpen ? "Fechar menu" : "Abrir menu"}
            aria-expanded={menuOpen}
            aria-controls="mobile-nav"
            onClick={() => setMenuOpen((o) => !o)}
            className="md:hidden border border-line bg-white text-navy w-9 h-9 rounded-lg flex items-center justify-center focus-ring"
          >
            {menuOpen ? "✕" : "☰"}
          </button>
        </div>
      </div>

      {/* Progress bar */}
      <div
        aria-hidden="true"
        className="absolute bottom-0 left-0 right-0 h-[2px] bg-line/50"
      >
        <div
          className="h-full bg-mint transition-all duration-100"
          style={{ width: `${progress}%` }}
        />
      </div>

      {/* Mobile nav */}
      <AnimatePresence>
        {menuOpen && (
          <motion.nav
            id="mobile-nav"
            aria-label="Navegação mobile"
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.2, ease: "easeOut" }}
            className="md:hidden absolute top-full left-0 right-0 flex flex-col gap-4 px-6 py-5 bg-white border-t border-line shadow-lg"
          >
            {NAV_LINKS.map((link) => (
              <NavLink
                key={link.href}
                href={link.href}
                label={link.label}
                onClick={closeMenu}
                isActive={activeSection === link.href.replace("#", "")}
              />
            ))}
            <Button href="#contato" className="self-start text-[11px] mt-1" onClick={closeMenu}>
              Falar do projeto ↗
            </Button>
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  );
}
