const ITEMS = "LANDING PAGES ✦ SITES CORPORATIVOS ✦ LOJAS VIRTUAIS ✦ HTML · CSS · JAVASCRIPT · PHP · PYTHON · SEO ✦ ";

export function MarqueeBar() {
  return (
    <div aria-hidden="true" className="bg-navy py-3.5 whitespace-nowrap overflow-hidden font-mono text-[11px] tracking-wider text-white/50">
      <div className="marquee-track inline-block">{ITEMS.repeat(4)}</div>
    </div>
  );
}
