import Image from "next/image";
import type { PortfolioCard as T } from "@/lib/types";

interface PortfolioCardProps { item: T; }

export function PortfolioCard({ item }: PortfolioCardProps) {
  return (
    <article
      className="h-[280px] rounded-xl overflow-hidden relative bg-navy group"
      aria-label={`Projeto: ${item.title}`}
    >
      <Image
        src={item.image}
        alt={item.imageAlt}
        fill
        className="object-cover transition-transform duration-500 group-hover:scale-105"
        sizes="(max-width: 768px) 100vw, 50vw"
      />
      <div
        aria-hidden="true"
        className="absolute inset-0 p-5 flex flex-col justify-end text-white bg-gradient-to-t from-navy/95 via-navy/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"
      >
        <small className="font-mono text-[9px] text-mint/90 mb-1">{item.badge}</small>
        <h3 className="font-display font-extrabold text-[22px] tracking-[-0.03em] my-1">
          {item.title}
        </h3>
        <p className="font-mono text-[9px] text-white/60">{item.stack}</p>
      </div>
    </article>
  );
}
