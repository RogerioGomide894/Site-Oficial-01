import Link from "next/link";

interface NavLinkProps {
  href: string;
  label: string;
  onClick?: () => void;
  isActive?: boolean;
}

export function NavLink({ href, label, onClick, isActive = false }: NavLinkProps) {
  return (
    <Link
      href={href}
      onClick={onClick}
      className={`text-[12px] font-bold no-underline transition-colors pb-0.5 focus-ring ${
        isActive
          ? "text-mint border-b-2 border-mint"
          : "text-ink-muted hover:text-navy border-b-2 border-transparent"
      }`}
    >
      {label}
    </Link>
  );
}
