import type { Testimonial } from "@/lib/types";
import { cn } from "@/lib/utils";

interface TestimonialBlockProps {
  item: Testimonial;
  isActive: boolean;
}

export function TestimonialBlock({ item, isActive }: TestimonialBlockProps) {
  return (
    <article
      role="group"
      aria-roledescription="slide"
      className={`max-w-[860px] min-h-[210px] transition-opacity duration-300 ${
        isActive ? "block animate-[fadeUp_0.5s_ease_forwards]" : "hidden"
      }`}
    >
      <blockquote className="font-display font-extrabold text-[clamp(20px,3vw,36px)] leading-[1.18] tracking-[-0.025em] my-6 mx-0 p-0 border-0 text-white">
        &ldquo;{item.quote}&rdquo;
      </blockquote>
      <div className="flex items-center gap-4">
        <div
          aria-hidden="true"
          className={cn(
            "w-11 h-11 rounded-full flex-shrink-0 grid place-items-center font-display font-extrabold text-[13px] text-white",
            item.avatarColor
          )}
        >
          {item.initials}
        </div>
        <cite className="not-italic">
          <span className="block font-display font-extrabold text-[14px] text-white">
            {item.author}
          </span>
          <span className="block font-mono text-[10px] text-mint mt-0.5">
            {item.role}
          </span>
        </cite>
      </div>
    </article>
  );
}
