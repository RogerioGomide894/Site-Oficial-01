import type { TechItem } from "@/lib/types";
import { cn } from "@/lib/utils";

interface TechCardProps {
  item: TechItem;
  index: number;
}

const symbolBg = [
  "bg-navy",
  "bg-mint",
  "bg-navy-mid",
  "bg-[#3b2f8f]",
  "bg-[#0d7a60]",
];

export function TechCard({ item, index }: TechCardProps) {
  return (
    <article className="min-h-[148px] bg-white rounded-xl p-5 flex flex-col shadow-card hover:shadow-card-hover hover:-translate-y-1 transition-all duration-300">
      <b
        aria-hidden="true"
        style={{ animationDelay: `${index * 0.4}s` }}
        className={cn(
          "grid place-items-center w-11 h-11 rounded-xl text-white font-mono font-bold text-[15px] mb-auto",
          "animate-[techFloat_3.5s_ease-in-out_infinite]",
          symbolBg[index] ?? "bg-navy"
        )}
      >
        {item.symbol}
      </b>
      <span className="font-display font-extrabold text-[15px] tracking-[-0.02em] mt-auto text-ink">
        {item.name}
      </span>
      <small className="text-ink-subtle text-[10px] mt-0.5 font-mono">{item.role}</small>
    </article>
  );
}
