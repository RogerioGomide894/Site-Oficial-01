"use client";
import { useState } from "react";
import { Button } from "@/components/atoms";
import { WA_HREF } from "@/lib/data";

const PROJECT_OPTIONS  = ["Landing page","Site corporativo","Loja virtual","Outro projeto web"];
const DEADLINE_OPTIONS = ["O quanto antes","Nas próximas 2 semanas","Nos próximos 30 dias","Ainda estou planejando"];
const BUDGET_OPTIONS   = ["A partir de R$ 500","Entre R$ 1.000 e R$ 2.500","Acima de R$ 2.500","Ainda não sei"];
interface FormState { nome:string; projeto:string; prazo:string; orcamento:string; }
const INITIAL:FormState = { nome:"", projeto:"", prazo:"", orcamento:"" };
const lbl = "flex flex-col gap-1.5 font-mono text-[9px] tracking-[1.2px] text-white/50 uppercase";
const fld = "mt-1 bg-white/8 border border-white/15 rounded-lg px-4 py-3.5 text-white text-[13px] min-h-[48px] placeholder:text-white/30 focus:outline-none focus:border-mint/60 focus-ring transition-colors";

export function ContactForm() {
  const [form, setForm] = useState<FormState>(INITIAL);
  const onChange = (e:React.ChangeEvent<HTMLInputElement|HTMLSelectElement>) =>
    setForm(p=>({...p,[e.target.name]:e.target.value}));
  const onSubmit = () => {
    const msg = encodeURIComponent(
      `Olá! Me chamo ${form.nome}.\nProjeto: ${form.projeto}\nPrazo: ${form.prazo}\nOrçamento: ${form.orcamento}`
    );
    window.open(`${WA_HREF}?text=${msg}`,"_blank","noopener");
  };
  return (
    <form onSubmit={e=>{e.preventDefault();onSubmit();}} className="flex flex-col gap-5 w-full max-w-[540px]" aria-label="Formulário de briefing rápido">
      <label className={lbl}>Seu nome<input name="nome" required placeholder="Como podemos chamar você?" value={form.nome} onChange={onChange} className={fld}/></label>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
        <label className={lbl}>Tipo de projeto
          <select name="projeto" required value={form.projeto} onChange={onChange} className={fld}>
            <option value="">Selecione</option>{PROJECT_OPTIONS.map(o=><option key={o}>{o}</option>)}
          </select>
        </label>
        <label className={lbl}>Prazo desejado
          <select name="prazo" required value={form.prazo} onChange={onChange} className={fld}>
            <option value="">Selecione</option>{DEADLINE_OPTIONS.map(o=><option key={o}>{o}</option>)}
          </select>
        </label>
      </div>
      <label className={lbl}>Orçamento estimado
        <select name="orcamento" required value={form.orcamento} onChange={onChange} className={fld}>
          <option value="">Selecione</option>{BUDGET_OPTIONS.map(o=><option key={o}>{o}</option>)}
        </select>
      </label>
      <Button type="submit" variant="primary" className="self-start mt-2">
        Enviar briefing pelo WhatsApp <span className="opacity-70">↗</span>
      </Button>
    </form>
  );
}
