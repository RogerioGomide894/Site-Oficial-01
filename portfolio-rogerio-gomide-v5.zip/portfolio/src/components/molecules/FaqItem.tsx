import type { FaqItem as FaqItemType } from "@/lib/types";

interface FaqItemProps {
  item: FaqItemType;
  defaultOpen?: boolean;
}

export function FaqItem({ item, defaultOpen = false }: FaqItemProps) {
  return (
    <details open={defaultOpen} className="border-b border-line py-5 group">
      <summary className="font-display font-extrabold text-[17px] tracking-[-0.02em] cursor-pointer list-none flex justify-between items-center hover:text-navy transition-colors">
        {item.question}
        <span
          aria-hidden="true"
          className="text-mint text-[20px] font-light ml-4 group-open:rotate-45 transition-transform duration-200 flex-shrink-0"
        >
          +
        </span>
      </summary>
      <p className="mt-4 mb-0 text-ink-muted text-[13px] leading-relaxed max-w-[540px]">
        {item.answer}
      </p>
    </details>
  );
}
