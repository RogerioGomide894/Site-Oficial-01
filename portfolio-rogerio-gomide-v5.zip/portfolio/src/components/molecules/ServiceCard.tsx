import type { ServiceItem } from "@/lib/types";

interface ServiceCardProps {
  item: ServiceItem;
  ctaHref?: string;
}

export function ServiceCard({ item, ctaHref = "#contato" }: ServiceCardProps) {
  return (
    <article className="border border-line bg-white rounded-xl p-6 relative flex flex-col min-h-[260px] transition-all duration-300 hover:-translate-y-1.5 hover:shadow-card-hover hover:border-navy/20">
      <span className="font-mono text-[9px] text-ink-subtle">{item.index}</span>
      <div
        aria-hidden="true"
        className="w-10 h-10 bg-mint-light grid place-items-center text-mint text-lg rounded-lg my-7"
      >
        {item.icon}
      </div>
      <h3 className="font-display font-extrabold text-[18px] tracking-[-0.03em] mb-2 text-ink">
        {item.title}
      </h3>
      <p className="text-[13px] leading-relaxed text-ink-muted flex-1">{item.description}</p>
      <a
        href={ctaHref}
        className="mt-5 text-[11px] font-extrabold no-underline text-navy hover:text-mint transition-colors inline-flex items-center gap-1.5"
      >
        {item.ctaLabel} <span className="text-mint">→</span>
      </a>
    </article>
  );
}
