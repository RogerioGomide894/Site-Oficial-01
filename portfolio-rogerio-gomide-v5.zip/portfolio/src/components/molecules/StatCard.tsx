import type { Stat } from "@/lib/types";

interface StatCardProps { item: Stat; }

export function StatCard({ item }: StatCardProps) {
  return (
    <div className="flex flex-col gap-1">
      <span className="font-display font-extrabold text-[clamp(30px,4vw,44px)] tracking-[-0.03em] leading-none text-mint">
        {item.value}
      </span>
      <span className="font-mono text-[9px] text-white/50 tracking-[1.2px] uppercase">
        {item.label}
      </span>
    </div>
  );
}
