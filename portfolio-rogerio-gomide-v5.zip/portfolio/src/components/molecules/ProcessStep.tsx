import type { ProcessStep as ProcessStepType } from "@/lib/types";

interface ProcessStepProps {
  step: ProcessStepType;
  isLast?: boolean;
  theme?: "dark" | "light";
}

export function ProcessStep({ step, isLast = false, theme = "dark" }: ProcessStepProps) {
  const isDark = theme === "dark";
  return (
    <article className={`pt-6 pr-4 pb-5 min-h-[180px] ${
      isLast ? "" : isDark ? "border-r border-white/10" : "border-r border-line"
    }`}>
      <span className={`font-mono text-[9px] tracking-wider ${isDark ? "text-mint" : "text-ink-subtle"}`}>
        {step.label}
      </span>
      <h3 className={`font-display font-extrabold text-[22px] tracking-[-0.02em] mt-8 mb-2 ${
        isDark ? "text-white" : "text-ink"
      }`}>{step.title}</h3>
      <p className={`m-0 text-[13px] leading-relaxed max-w-[210px] ${
        isDark ? "text-white/50" : "text-ink-muted"
      }`}>{step.description}</p>
    </article>
  );
}
