import Link from "next/link";

export function Logo() {
  return (
    <Link
      href="#inicio"
      className="flex items-center gap-2.5 no-underline group"
      aria-label="Rogério Gomide — ir para o início"
    >
      <span
        aria-hidden="true"
        className="grid place-items-center w-9 h-9 rounded-full bg-navy text-white font-display text-[10px] tracking-[-0.5px] font-extrabold flex-shrink-0 group-hover:bg-mint transition-colors duration-200"
      >
        RG
      </span>
      <span className="font-display text-[12px] font-extrabold tracking-[-0.3px] leading-none text-navy">
        ROGÉRIO GOMIDE
        <small className="block font-mono text-[6.5px] tracking-[1.2px] mt-0.5 text-ink-muted">
          DESENVOLVEDOR WEB · FULL STACK
        </small>
      </span>
    </Link>
  );
}
