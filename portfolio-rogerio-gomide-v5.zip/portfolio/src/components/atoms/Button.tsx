import { cn } from "@/lib/utils";
import Link from "next/link";

type ButtonVariant = "primary" | "outline" | "ghost";

interface ButtonProps {
  children: React.ReactNode;
  href?: string;
  variant?: ButtonVariant;
  className?: string;
  onClick?: () => void;
  type?: "button" | "submit" | "reset";
  "aria-label"?: string;
  external?: boolean;
}

// Laranja removido — verde-menta é o único acento
const variantStyles: Record<ButtonVariant, string> = {
  primary:
    "bg-mint text-white hover:bg-mint-dark shadow-float hover:-translate-y-0.5",
  outline:
    "border border-navy text-navy bg-transparent hover:bg-navy hover:text-white hover:-translate-y-0.5",
  ghost:
    "border border-white/30 text-white bg-transparent hover:bg-white/10 hover:-translate-y-0.5",
};

export function Button({
  children,
  href,
  variant = "primary",
  className,
  onClick,
  type = "button",
  external,
  "aria-label": ariaLabel,
}: ButtonProps) {
  const base = cn(
    "inline-flex items-center gap-3 px-5 py-3.5 rounded-lg",
    "text-[12px] font-extrabold font-sans tracking-wide",
    "transition-all duration-200 cursor-pointer focus-ring",
    variantStyles[variant],
    className
  );

  if (href) {
    return (
      <Link
        href={href}
        className={base}
        aria-label={ariaLabel}
        {...(external && { target: "_blank", rel: "noopener noreferrer" })}
      >
        {children}
      </Link>
    );
  }

  return (
    <button type={type} onClick={onClick} className={base} aria-label={ariaLabel}>
      {children}
    </button>
  );
}
