"use client";

interface ThemeToggleProps {
  isDark: boolean;
  onToggle: () => void;
}

export function ThemeToggle({ isDark, onToggle }: ThemeToggleProps) {
  return (
    <button
      type="button"
      onClick={onToggle}
      aria-label={isDark ? "Ativar modo claro" : "Ativar modo escuro"}
      aria-pressed={isDark}
      className="border border-line text-navy bg-white w-9 h-9 rounded-lg text-base flex items-center justify-center hover:bg-navy-faint transition-colors focus-ring"
    >
      {isDark ? "○" : "◐"}
    </button>
  );
}
