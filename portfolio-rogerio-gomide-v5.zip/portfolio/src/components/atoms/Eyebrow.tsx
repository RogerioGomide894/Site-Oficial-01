import { cn } from "@/lib/utils";

interface EyebrowProps {
  children: React.ReactNode;
  variant?: "light" | "dark";
  className?: string;
}

export function Eyebrow({ children, variant = "light", className }: EyebrowProps) {
  return (
    <p
      className={cn(
        "font-mono text-[10px] font-medium tracking-[1.5px] mb-5 flex items-center gap-2 uppercase",
        variant === "light" ? "text-ink-muted" : "text-white/60",
        className
      )}
    >
      <span
        aria-hidden="true"
        className={cn(
          "inline-block w-1.5 h-1.5 rounded-full flex-shrink-0",
          variant === "light" ? "bg-mint" : "bg-mint"
        )}
      />
      {children}
    </p>
  );
}
