import Link from "next/link";
import { cn } from "@/lib/utils";

interface InlineLinkProps {
  href: string;
  children: React.ReactNode;
  className?: string;
  external?: boolean;
}

export function InlineLink({ href, children, className, external }: InlineLinkProps) {
  return (
    <Link
      href={href}
      className={cn(
        "text-[12px] font-extrabold text-ink-muted no-underline hover:text-navy transition-colors inline-flex items-center gap-1.5",
        className
      )}
      {...(external && { target: "_blank", rel: "noopener noreferrer" })}
    >
      {children}
      <span className="text-mint text-[16px] font-normal">→</span>
    </Link>
  );
}
