import { cn } from "@/lib/utils";

type HeadingLevel = "h1" | "h2" | "h3";
type HeadingSize  = "xl" | "lg" | "md" | "sm";

interface HeadingProps {
  as?: HeadingLevel;
  size?: HeadingSize;
  children: React.ReactNode;
  className?: string;
  accentColor?: "navy" | "mint" | "white-mint";
  id?: string;
}

// clamp com tracking proporcional ao tamanho — sem -4px fixo
const sizeStyles: Record<HeadingSize, string> = {
  xl: "text-[clamp(40px,5.5vw,72px)] leading-[0.97] tracking-[-0.03em]",
  lg: "text-[clamp(32px,4vw,54px)]  leading-[1.02] tracking-[-0.025em]",
  md: "text-[clamp(28px,3.5vw,46px)] leading-[1.05] tracking-[-0.022em]",
  sm: "text-[clamp(20px,2.5vw,26px)] leading-[1.15] tracking-[-0.015em]",
};

const accentStyles: Record<string, string> = {
  navy:       "[&_em]:text-navy       [&_em]:not-italic",
  mint:       "[&_em]:text-mint       [&_em]:not-italic",
  "white-mint": "[&_em]:text-mint     [&_em]:not-italic",
};

export function Heading({
  as: Tag = "h2",
  size = "lg",
  children,
  className,
  accentColor = "navy",
  id,
}: HeadingProps) {
  return (
    <Tag
      id={id}
      className={cn(
        "font-display font-extrabold m-0",
        sizeStyles[size],
        accentStyles[accentColor],
        className
      )}
    >
      {children}
    </Tag>
  );
}
